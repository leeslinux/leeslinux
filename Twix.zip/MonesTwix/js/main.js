// **********************************
// *   main.js for WeatherHTML 2.0  *
// *        by thewaytozion         *
// **********************************

// *********************************************************************
// * HINTS                                                             *
// *                                                                   *
// * Changing or deleting JS code here may stop WeatherHTML 2.0 to run *
// * Add your items at the end of this file                            *
// * or whithin DOMContenLoaded section                                *
// *********************************************************************

// Progress defined in HTMLModul of WeatherHTML 2.0 Shortcut
progress = progress - 40;
document.getElementById('SunMoon').style.left = progress+"%"; 

// Hide/Show divs based on config.js defintions
if (showdailyforecast===1) {
    document.getElementById('dailyC').style.opacity = "1";
    document.getElementById('daybarbox').style.opacity = "1";
} else {
    document.getElementById('dailyC').style.opacity = "0"; 
    document.getElementById('daybarbox').style.opacity = "0";
}

if (showhourlyforecast===1) {
    document.getElementById('hourlyC').style.opacity = "1"; 
    document.getElementById('hourbox').style.opacity = "1"; 
} else {
    document.getElementById('hourlyC').style.opacity = "0"; 
    document.getElementById('hourbox').style.opacity = "0"; 
}

if (showProfPic===1) {
    document.getElementById('profilediv').style.opacity = "1"; 
} else {
    document.getElementById('profilediv').style.opacity = "0"; 
}

if (useCalendar===1) {
    //document.getElementById('calheader').style.opacity = "1"; 
    //document.getElementById('todayheader').style.opacity = "1"; 
    //document.getElementById('tomorrowheader').style.opacity = "1"; 
    if (todayentries===0) {
        document.getElementById('todayheader').style.opacity = "0";     
    }
    if ((todayentries>=1) && (hideTomorrowCalEntriesIfTodayEntryFound===1)) {
        document.getElementById('tomorrowheader').style.opacity = "0"; 
        document.getElementById('tomorrowentries').style.opacity = "0"; 
    }
    if (tomorrowentries===0) {
        document.getElementById('tomorrowheader').style.opacity = "0"; 
    }
} else {
    document.getElementById('calheader').style.opacity = "0"; 
    document.getElementById('todayheader').style.opacity = "0"; 
    document.getElementById('tomorrowheader').style.opacity = "0"; 
}

if (usecoloredtemperature===1) {
	document.getElementById('temp').style.color = tempColor(tempinC);
	document.getElementById('high').style.color = tempColor(highinC);
	document.getElementById('low').style.color = tempColor(lowinC);
}

// Color Functions for Temperature and Battery
function tempColor(temp) {
    if (useFahrenheit === 1) { 
		temp = (temp-32)*5/9; 
	}
 	var hightempscale = 30;
 	var lowtempscale = -15;	
 	if (temp > hightempscale) {temp = hightempscale;}
 	if (temp < lowtempscale) {temp = lowtempscale;}
    var hue = 250 * (hightempscale - temp) / (hightempscale - lowtempscale);
    color = 'hsl(' + [hue, '100%', '40%'] + ')';
	return color;
}

function batteryColor1(status) {
	var color = "#000000";
	if (status >= 90) { 
		color = "#38ef7d";
	} else if (status >= 70) {
		color = "#93F9B9";
	} else if (status >= 50) {
		color = "#DCE35B";
	} else if (status >= 35) {
		color = "#CAC531";
	} else if (status >= 20) {
		color = "#F2C94C";
	} else if (status >= 10) {
		color = "#f7b733";	
	} else {
		color = "#ED213A";
	}
	return color;
}

function batteryColor2(status) {
	var color = "#000000";
	if (status >= 90) { 
		color = "#11998e";
	} else if (status >= 70) {
		color = "#1D976C";
	} else if (status >= 50) {
		color = "#45B649";
	} else if (status >= 35) {
		color = "#F3F9A7";
	} else if (status >= 20) {
		color = "#F2994A";
	} else if (status >= 10) {
		color = "#fc4a1a";	
	} else {
		color = "#93291E";
	}
	return color;
}

// Add you custom JS below

// wait for all DOMs loaded 
document.addEventListener("DOMContentLoaded", function(event) { 
    //Battery
    if (useBatteryCircle===1) {
        var batterylevelcircle = batterylevel/100;
       document.getElementById("labelcircle").innerHTML = batterylevel + "%";
       document.getElementById("labelcircle").style.color = batteryColor2(batterylevel);
       $('#batterycircle').circleProgress({
            value: batterylevelcircle,
            size: 60,
            thickness: 6,
            lineCap: "round",
            startAngle: -0.5 * Math.PI,
            animation: false,
            fill: {
                gradient: [batteryColor1(batterylevel), batteryColor2(batterylevel)]
            }
        });

    }
    // RSS cut off 
    var RSSArticle = document.getElementById("RSSText").innerHTML;
    if (RSSArticle.length > charcountRSS) {
        document.getElementById("RSSText").innerHTML = RSSArticle.slice(0, charcountRSS) + " ...";
    }
    // Get device language	
	var getlanguage = navigator.language || navigator.userLanguage;
    var language = getlanguage.split('-');
    var languageDev = language[0].toLowerCase();

    // Gather moon phase, you might add your lagnauge case
    switch(languageDev) {
        case "de":
            switch(MoonPhaseNumber) {
                case 0:
                    document.getElementById("moonphase").innerHTML = 'New-Moon';
                break;
                case 1:
                    document.getElementById("moonphase").innerHTML = 'Waxing-Crescent-Moon';
                break;
                case 2:
                    document.getElementById("moonphase").innerHTML = 'Quarter-Moon';
                break;
                case 3:
                    document.getElementById("moonphase").innerHTML = 'Waxing-Gibbous-Moon';
                break;
                case 4:
                    document.getElementById("moonphase").innerHTML = 'Full-Moon';
                break;
                case 5:
                    document.getElementById("moonphase").innerHTML = 'Waning-Gibbous-Moon';
                break;
                case 6:
                    document.getElementById("moonphase").innerHTML = 'Last-Quarter-Moon';
                break;
                case 7:
                    document.getElementById("moonphase").innerHTML ='Waning-Crescent-Moon';
                break;
                default:
                    document.getElementById("moonphase").innerHTML ='Error';
                break;
            }
        break;
				
				
			
        default:
            switch(MoonPhaseNumber) {
                case 0:
                    document.getElementById("moonphase").innerHTML = 'New-Moon';
                break;
                case 1:
                    document.getElementById("moonphase").innerHTML = 'Waxing-Crescent-Moon';
                break;
                case 2:
                    document.getElementById("moonphase").innerHTML = 'Quarter-Moon';
                break;
                case 3:
                    document.getElementById("moonphase").innerHTML = 'Waxing-Gibbous-Moon';
                break;
                case 4:
                    document.getElementById("moonphase").innerHTML = 'Full-Moon';
                break;
                case 5:
                    document.getElementById("moonphase").innerHTML = 'Waning-Gibbous-Moon';
                break;
                case 6:
                    document.getElementById("moonphase").innerHTML = 'Last-Quarter-Moon';
                break;
                case 7:
                    document.getElementById("moonphase").innerHTML ='Waning-Crescent-Moon';
                break;
                default:
                    document.getElementById("moonphase").innerHTML ='Error';
                break;
            }
        break;
    }
        

    // Date Formating using moment JS library (added in /js/library.html)
    var now = new Date();
    var nowhr = now.getHours();
    var nowmin = now.getMinutes();
    var nowday = now.getDate();
    moment.locale(language[0]);
    var date = moment(); 
    // date formats defined in config.js
    var dateformat1 = date.format(date1); 
    var dateformat2 = date.format(date2); 
    var dateformat3 = date.format(date3); 
    document.getElementById("date1").innerHTML = dateformat1;
    document.getElementById("date2").innerHTML = dateformat2;
    document.getElementById("date3").innerHTML = dateformat3;

    // Week LineCal Table
    if (showweeklyCalendar===1) {
        var startDate = moment().startOf('week');
        startDate.startOf('day');
        startDate.subtract(1, 'days');
        var table = "<table id='WeekCalTable'>";
        var table = table + "<tr>";
        var j = 0;
        var startDate0 = moment().startOf('week');
        startDate0.startOf('day');
        startDate0.subtract(1, 'days');
        for (var i = 0; i < 7; i++) { 
            var dayrunner0 = startDate0.add(1, 'days').format("D");
            if (dayrunner0==nowday) { j= i;}
        }
        for (var i = 0; i < 7; i++) { 
            if (i == j) {
                var table = table + "<td class='weekcal' align='center' valign='center'><span class='weekhighlight'>";
            } else {
                var table = table + "<td class='weekcal' align='center' valign='center'><span>";
            }
          var dayrunner = startDate.add(1, 'days').format("ddd");
          var table = table + dayrunner;
          var table = table + "</span></td>";
        }
        var table = table + "</tr>";
        var startDate2 = moment().startOf('week');
        startDate2.startOf('day');
        startDate2.subtract(1, 'days');
        var table = table + "<tr>";
        for (var i = 0; i < 7; i++) { 
            if (i == j) {
                var table = table + "<td class='weekcal' align='center' valign='center'><span class='weekhighlight'>";
            } else {
                var table = table + "<td class='weekcal' align='center' valign='center'><span>";
            }
            var dayrunner2 = startDate2.add(1, 'days').format("D");
            var table = table + dayrunner2;
            var table = table + "</td>";
        }
        var table = table + "</tr>";
        var table = table + "</table>";
        $('#WeekCal').append(table);
    }

    // now define some variables using weather data
    var descstring = document.getElementById("desc").innerHTML;
    var tempstring = document.getElementById("temp").innerHTML;
    var citystring = document.getElementById("city").innerHTML;
    var hiday0 = document.getElementById("hiday0").innerHTML;
    var hiday1 = document.getElementById("hiday1").innerHTML;
    var hiday2 = document.getElementById("hiday2").innerHTML;
    var hiday3 = document.getElementById("hiday3").innerHTML;
    var hiday4 = document.getElementById("hiday4").innerHTML;
    var hiday5 = document.getElementById("hiday5").innerHTML;
    var loday0 = document.getElementById("loday0").innerHTML;
    var loday1 = document.getElementById("loday1").innerHTML;
    var loday2 = document.getElementById("loday2").innerHTML;
    var loday3 = document.getElementById("loday3").innerHTML;
    var loday4 = document.getElementById("loday4").innerHTML;
    var loday5 = document.getElementById("loday5").innerHTML;
    hiday0 = parseInt(hiday0.split('°')[0]);
    hiday1 = parseInt(hiday1.split('°')[0]);
    hiday2 = parseInt(hiday2.split('°')[0]);
    hiday3 = parseInt(hiday3.split('°')[0]);
    hiday4 = parseInt(hiday4.split('°')[0]);
    hiday5 = parseInt(hiday5.split('°')[0]);
    loday0 = parseInt(loday0.split('°')[0]);
    loday1 = parseInt(loday1.split('°')[0]);
    loday2 = parseInt(loday2.split('°')[0]);
    loday3 = parseInt(loday3.split('°')[0]);
    loday4 = parseInt(loday4.split('°')[0]);
    loday5 = parseInt(loday5.split('°')[0]);
    // Now perform some calcs for daily weather bar y-values
    var span0 = hiday0 - loday0;
    var span1 = hiday1 - loday1;
    var span2 = hiday2 - loday2;
    var span3 = hiday3 - loday3;
    var span4 = hiday4 - loday4;
    var span5 = hiday5 - loday5;
    var maxtemp = Math.max(hiday0, hiday1, hiday2, hiday3, hiday4, hiday5);
    var mintemp = Math.min(loday0, loday1, loday2, loday3, loday4, loday5);
    var maxspan = Math.max(span0, span1, span2, span3, span4, span5);
    var minspan = Math.min(span0, span1, span2, span3, span4, span5);
    var topbary = 77.6;
    var hitxty = topbary - 19.8;
    var lowtxty = topbary - 17;
    var barmaxheight = 6.5;
    if ((maxtemp-mintemp) === 0) {
        var deltaheightperK = barmaxheight;
    } else {
        var deltaheightperK = barmaxheight/(maxtemp-mintemp);    
    }
    if (usecoloredtemperature===1) {
            document.getElementById("hiday0").style.color = tempColor(hiday0); 
            document.getElementById("hiday1").style.color = tempColor(hiday1); 
            document.getElementById("hiday2").style.color = tempColor(hiday2); 
            document.getElementById("hiday3").style.color = tempColor(hiday3); 
            document.getElementById("hiday4").style.color = tempColor(hiday4); 
            document.getElementById("hiday5").style.color = tempColor(hiday5); 
            document.getElementById("loday0").style.color = tempColor(loday0); 
            document.getElementById("loday1").style.color = tempColor(loday1); 
            document.getElementById("loday2").style.color = tempColor(loday2); 
            document.getElementById("loday3").style.color = tempColor(loday3); 
            document.getElementById("loday4").style.color = tempColor(loday4); 
            document.getElementById("loday5").style.color = tempColor(loday5); 
            document.getElementById("day0bar").style.background = "-webkit-linear-gradient(90deg," + tempColor(loday0) + " 0%, " + tempColor(hiday0) + " 100%)";
            document.getElementById("day1bar").style.background = "-webkit-linear-gradient(90deg," + tempColor(loday1) + " 0%, " + tempColor(hiday1) + " 100%)";
            document.getElementById("day2bar").style.background = "-webkit-linear-gradient(90deg," + tempColor(loday2) + " 0%, " + tempColor(hiday2) + " 100%)";
            document.getElementById("day3bar").style.background = "-webkit-linear-gradient(90deg," + tempColor(loday3) + " 0%, " + tempColor(hiday3) + " 100%)";
            document.getElementById("day4bar").style.background = "-webkit-linear-gradient(90deg," + tempColor(loday4) + " 0%, " + tempColor(hiday4) + " 100%)";
            document.getElementById("day5bar").style.background = "-webkit-linear-gradient(90deg," + tempColor(loday5) + " 0%, " + tempColor(hiday5) + " 100%)";
    }
    document.getElementById("day0bar").style.top = (topbary+(maxtemp-hiday0)*deltaheightperK)+"%";
    document.getElementById("day0bar").style.height = ((hiday0-loday0)*deltaheightperK)+"%";
    document.getElementById("day0barBG").style.top = (topbary)+"%";
    document.getElementById("day0barBG").style.height = ((maxtemp-mintemp)*deltaheightperK)+"%";
    document.getElementById("day1bar").style.top = (topbary+(maxtemp-hiday1)*deltaheightperK)+"%";
    document.getElementById("day1bar").style.height = ((hiday1-loday1)*deltaheightperK)+"%";
    document.getElementById("day1barBG").style.top = (topbary)+"%";
    document.getElementById("day1barBG").style.height = ((maxtemp-mintemp)*deltaheightperK)+"%";
    document.getElementById("day2bar").style.top = (topbary+(maxtemp-hiday2)*deltaheightperK)+"%";
    document.getElementById("day2bar").style.height = ((hiday2-loday2)*deltaheightperK)+"%";
    document.getElementById("day2barBG").style.top = (topbary)+"%";
    document.getElementById("day2barBG").style.height = ((maxtemp-mintemp)*deltaheightperK)+"%";
    document.getElementById("day3bar").style.top = (topbary+(maxtemp-hiday3)*deltaheightperK)+"%";
    document.getElementById("day3bar").style.height = ((hiday3-loday3)*deltaheightperK)+"%";
    document.getElementById("day3barBG").style.top = (topbary)+"%";
    document.getElementById("day3barBG").style.height = ((maxtemp-mintemp)*deltaheightperK)+"%";
    document.getElementById("day4bar").style.top = (topbary+(maxtemp-hiday4)*deltaheightperK)+"%";
    document.getElementById("day4bar").style.height = ((hiday4-loday4)*deltaheightperK)+"%";
    document.getElementById("day4barBG").style.top = (topbary)+"%";
    document.getElementById("day4barBG").style.height = ((maxtemp-mintemp)*deltaheightperK)+"%";
    document.getElementById("day5bar").style.top = (topbary+(maxtemp-hiday5)*deltaheightperK)+"%";
    document.getElementById("day5bar").style.height = ((hiday5-loday5)*deltaheightperK)+"%";
    document.getElementById("day5barBG").style.top = (topbary)+"%";
    document.getElementById("day5barBG").style.height = ((maxtemp-mintemp)*deltaheightperK)+"%";
    var day0 = document.getElementById("day0").innerHTML;
    var day1 = document.getElementById("day1").innerHTML;
    var day2 = document.getElementById("day2").innerHTML;
    var day3 = document.getElementById("day3").innerHTML;
    var day4 = document.getElementById("day4").innerHTML;
    var day5 = document.getElementById("day5").innerHTML;
    if (language[0]==="de") {
        document.getElementById("day0").innerHTML = day0.slice(0, 2)+".";
        document.getElementById("day1").innerHTML = day1.slice(0, 2)+".";
        document.getElementById("day2").innerHTML = day2.slice(0, 2)+".";
        document.getElementById("day3").innerHTML = day3.slice(0, 2)+".";
        document.getElementById("day4").innerHTML = day4.slice(0, 2)+".";
        document.getElementById("day5").innerHTML = day5.slice(0, 2)+".";
     } else {
        document.getElementById("day0").innerHTML = day0.slice(0, 3)+"";
        document.getElementById("day1").innerHTML = day1.slice(0, 3)+"";
        document.getElementById("day2").innerHTML = day2.slice(0, 3)+"";
        document.getElementById("day3").innerHTML = day3.slice(0, 3)+"";
        document.getElementById("day4").innerHTML = day4.slice(0, 3)+"";
        document.getElementById("day5").innerHTML = day5.slice(0, 3)+"";
    }
    var precd0 = document.getElementById("precd0").innerHTML;
    var precd1 = document.getElementById("precd1").innerHTML;
    var precd2 = document.getElementById("precd2").innerHTML;
    var precd3 = document.getElementById("precd3").innerHTML;
    var precd4 = document.getElementById("precd4").innerHTML;
    var precd5 = document.getElementById("precd5").innerHTML;
    precd0 = parseInt(precd0.split(' %')[0]);
    precd1 = parseInt(precd1.split(' %')[0]);
    precd2 = parseInt(precd2.split(' %')[0]);
    precd3 = parseInt(precd3.split(' %')[0]);
    precd4 = parseInt(precd4.split(' %')[0]);
    precd5 = parseInt(precd5.split(' %')[0]);
    // only show precipitation if likelyhood is greater or equal 40%
    if (precd0 >= 40) {
        document.getElementById("precd0").innerHTML = precd0+"%";
    } else {
        document.getElementById("precd0").innerHTML = " ";
    }
    if (precd1 >= 40) {
        document.getElementById("precd1").innerHTML = precd1+"%";
    } else {
        document.getElementById("precd1").innerHTML = " ";
    }
    if (precd2 >= 40) {
        document.getElementById("precd2").innerHTML = precd2+"%";
    } else {
        document.getElementById("precd2").innerHTML = " ";
    }
    if (precd3 >= 40) {
        document.getElementById("precd3").innerHTML = precd3+"%";
    } else {
        document.getElementById("precd3").innerHTML = " ";
    }
    if (precd4 >= 40) {
        document.getElementById("precd4").innerHTML = precd4+"%";
    } else {
        document.getElementById("precd4").innerHTML = " ";
    }
    if (precd5 >= 40) {
        document.getElementById("precd5").innerHTML = precd5+"%";
    } else {
        document.getElementById("precd5").innerHTML = " ";
    }
   
    var prech0 = document.getElementById("prech0").innerHTML;
    var prech1 = document.getElementById("prech1").innerHTML;
    var prech2 = document.getElementById("prech2").innerHTML;
    var prech3 = document.getElementById("prech3").innerHTML;
    var prech4 = document.getElementById("prech4").innerHTML;
    var prech5 = document.getElementById("prech5").innerHTML;
    prech0 = parseInt(prech0.split('%')[0]);
    prech1 = parseInt(prech1.split('%')[0]);
    prech2 = parseInt(prech2.split('%')[0]);
    prech3 = parseInt(prech3.split('%')[0]);
    prech4 = parseInt(prech4.split('%')[0]);
    prech5 = parseInt(prech5.split('%')[0]);
    if (prech0 >= 40) {
        document.getElementById("prech0").innerHTML = prech0+"%";
    } else {
        document.getElementById("prech0").innerHTML = " ";
    }
    if (prech1 >= 40) {
        document.getElementById("prech1").innerHTML = prech1+"%";
    } else {
        document.getElementById("prech1").innerHTML =" ";
    }
    if (prech2 >= 40) {
        document.getElementById("prech2").innerHTML = prech2+"%";
    } else {
        document.getElementById("prech2").innerHTML = " ";
    }
    if (prech3 >= 40) {
        document.getElementById("prech3").innerHTML = prech3+"%";
    } else {
        document.getElementById("prech3").innerHTML = " ";
    }
    if (prech4 >= 40) {
        document.getElementById("prech4").innerHTML = prech4+"%";
    } else {
        document.getElementById("prech4").innerHTML = " ";
    }
    if (prech5 >= 40) {
        document.getElementById("prech5").innerHTML = prech5+"%";
    } else {
        document.getElementById("prech5").innerHTML = " ";
    }
    var hour0 = document.getElementById("hour0").innerHTML;
    var hour1 = document.getElementById("hour1").innerHTML;
    var hour2 = document.getElementById("hour2").innerHTML;
    var hour3 = document.getElementById("hour3").innerHTML;
    var hour4 = document.getElementById("hour4").innerHTML;
    var hour5 = document.getElementById("hour5").innerHTML;
    document.getElementById("hourtxt0").innerHTML = hour0 + clockstring;
    document.getElementById("hourtxt1").innerHTML = hour1 + clockstring;
    document.getElementById("hourtxt2").innerHTML = hour2 + clockstring;
    document.getElementById("hourtxt3").innerHTML = hour3 + clockstring;
    document.getElementById("hourtxt4").innerHTML = hour4 + clockstring;
    document.getElementById("hourtxt5").innerHTML = hour5 + clockstring;
                
    // gather 24 hr forecast data, used for e.g. radial weather
    var hr0 = document.getElementById("temphour0").innerHTML;
    var hr1 = document.getElementById("temphour1").innerHTML;
    var hr2 = document.getElementById("temphour2").innerHTML;
    var hr3 = document.getElementById("temphour3").innerHTML;
    var hr4 = document.getElementById("temphour4").innerHTML;
    var hr5 = document.getElementById("temphour5").innerHTML;
    var hr6 = document.getElementById("temphour6").innerHTML;
    var hr7 = document.getElementById("temphour7").innerHTML;
    var hr8 = document.getElementById("temphour8").innerHTML;
    var hr9 = document.getElementById("temphour9").innerHTML;
    var hr10 = document.getElementById("temphour10").innerHTML;
    var hr11 = document.getElementById("temphour11").innerHTML;
    var hr12 = document.getElementById("temphour12").innerHTML;
    var hr13 = document.getElementById("temphour13").innerHTML;
    var hr14 = document.getElementById("temphour14").innerHTML;
    var hr15 = document.getElementById("temphour15").innerHTML;
    var hr16 = document.getElementById("temphour16").innerHTML;
    var hr17 = document.getElementById("temphour17").innerHTML;
    var hr18 = document.getElementById("temphour18").innerHTML;
    var hr19 = document.getElementById("temphour19").innerHTML;
    var hr20 = document.getElementById("temphour20").innerHTML;
    var hr21 = document.getElementById("temphour21").innerHTML;
    var hr22 = document.getElementById("temphour22").innerHTML;
    var hr23 = document.getElementById("temphour23").innerHTML;
    hr0 = parseInt(hr0.split('°')[0]);
    hr1 = parseInt(hr1.split('°')[0]);
    hr2 = parseInt(hr2.split('°')[0]);
    hr3 = parseInt(hr3.split('°')[0]);
    hr4 = parseInt(hr4.split('°')[0]);
    hr5 = parseInt(hr5.split('°')[0]);
    hr6 = parseInt(hr6.split('°')[0]);
    hr7 = parseInt(hr7.split('°')[0]);
    hr8 = parseInt(hr8.split('°')[0]);
    hr9 = parseInt(hr9.split('°')[0]);
    hr10 = parseInt(hr10.split('°')[0]);
    hr11 = parseInt(hr11.split('°')[0]);
    hr12 = parseInt(hr12.split('°')[0]);
    hr13 = parseInt(hr13.split('°')[0]);
    hr14 = parseInt(hr14.split('°')[0]);
    hr15 = parseInt(hr15.split('°')[0]);
    hr16 = parseInt(hr16.split('°')[0]);
    hr17 = parseInt(hr17.split('°')[0]);
    hr18 = parseInt(hr18.split('°')[0]);
    hr19 = parseInt(hr19.split('°')[0]);
    hr20 = parseInt(hr20.split('°')[0]);
    hr21 = parseInt(hr21.split('°')[0]);
    hr22 = parseInt(hr22.split('°')[0]);
    hr23 = parseInt(hr23.split('°')[0]);
    var hrclock0 = document.getElementById("hour0").innerHTML;
    var hrclock1 = document.getElementById("hour1").innerHTML;
    var hrclock2 = document.getElementById("hour2").innerHTML;
    var hrclock3 = document.getElementById("hour3").innerHTML;
    var hrclock4 = document.getElementById("hour4").innerHTML;
    var hrclock5 = document.getElementById("hour5").innerHTML;
    var hrclock6 = document.getElementById("hour6").innerHTML;
    var hrclock7 = document.getElementById("hour7").innerHTML;
    var hrclock8 = document.getElementById("hour8").innerHTML;
    var hrclock9 = document.getElementById("hour9").innerHTML;
    var hrclock10 = document.getElementById("hour10").innerHTML;
    var hrclock11 = document.getElementById("hour11").innerHTML;
    var hrclock12 = document.getElementById("hour12").innerHTML;
    var hrclock13 = document.getElementById("hour13").innerHTML;
    var hrclock14 = document.getElementById("hour14").innerHTML;
    var hrclock15 = document.getElementById("hour15").innerHTML;
    var hrclock16 = document.getElementById("hour16").innerHTML;
    var hrclock17 = document.getElementById("hour17").innerHTML;
    var hrclock18 = document.getElementById("hour18").innerHTML;
    var hrclock19 = document.getElementById("hour19").innerHTML;
    var hrclock20 = document.getElementById("hour20").innerHTML;
    var hrclock21 = document.getElementById("hour21").innerHTML;
    var hrclock22 = document.getElementById("hour22").innerHTML;
    var hrclock23 = document.getElementById("hour23").innerHTML;
    var maxhr = Math.max(hr0, hr1, hr2, hr3, hr4, hr5, hr6, hr7, hr8, hr9, hr10, hr11, hr12, hr13, hr14, hr15, hr16, hr17, hr18, hr19, hr20, hr21, hr22, hr23);
    var minhr = Math.min(hr0, hr1, hr2, hr3, hr4, hr5, hr6, hr7, hr8, hr9, hr10, hr11, hr12, hr13, hr14, hr15, hr16, hr17, hr18, hr19, hr20, hr21, hr22, hr23);
    var prechr0 = document.getElementById("prech0").innerHTML;
    var prechr1 = document.getElementById("prech1").innerHTML;
    var prechr2 = document.getElementById("prech2").innerHTML;
    var prechr3 = document.getElementById("prech3").innerHTML;
    var prechr4 = document.getElementById("prech4").innerHTML;
    var prechr5 = document.getElementById("prech5").innerHTML;
    var prechr6 = document.getElementById("prech6").innerHTML;
    var prechr7 = document.getElementById("prech7").innerHTML;
    var prechr8 = document.getElementById("prech8").innerHTML;
    var prechr9 = document.getElementById("prech9").innerHTML;
    var prechr10 = document.getElementById("prech10").innerHTML;
    var prechr11 = document.getElementById("prech11").innerHTML;
    var prechr12 = document.getElementById("prech12").innerHTML;
    var prechr13 = document.getElementById("prech13").innerHTML;
    var prechr14 = document.getElementById("prech14").innerHTML;
    var prechr15 = document.getElementById("prech15").innerHTML;
    var prechr16 = document.getElementById("prech16").innerHTML;
    var prechr17 = document.getElementById("prech17").innerHTML;
    var prechr18 = document.getElementById("prech18").innerHTML;
    var prechr19 = document.getElementById("prech19").innerHTML;
    var prechr20 = document.getElementById("prech20").innerHTML;
    var prechr21 = document.getElementById("prech21").innerHTML;
    var prechr22 = document.getElementById("prech22").innerHTML;
    var prechr23 = document.getElementById("prech23").innerHTML;
    prechr0 = parseInt(prechr0.split('%')[0]);
    prechr1 = parseInt(prechr1.split('%')[0]);
    prechr2 = parseInt(prechr2.split('%')[0]);
    prechr3 = parseInt(prechr3.split('%')[0]);
    prechr4 = parseInt(prechr4.split('%')[0]);
    prechr5 = parseInt(prechr5.split('%')[0]);
    prechr6 = parseInt(prechr6.split('%')[0]);
    prechr7 = parseInt(prechr7.split('%')[0]);
    prechr8 = parseInt(prechr8.split('%')[0]);
    prechr9 = parseInt(prechr9.split('%')[0]);
    prechr10 = parseInt(prechr10.split('%')[0]);
    prechr11 = parseInt(prechr11.split('%')[0]);
    prechr12 = parseInt(prechr12.split('%')[0]);
    prechr13 = parseInt(prechr13.split('%')[0]);
    prechr14 = parseInt(prechr14.split('%')[0]);
    prechr15 = parseInt(prechr15.split('%')[0]);
    prechr16 = parseInt(prechr16.split('%')[0]);
    prechr17 = parseInt(prechr17.split('%')[0]);
    prechr18 = parseInt(prechr18.split('%')[0]);
    prechr19 = parseInt(prechr19.split('%')[0]);
    prechr20 = parseInt(prechr20.split('%')[0]);
    prechr21 = parseInt(prechr21.split('%')[0]);
    prechr22 = parseInt(prechr22.split('%')[0]);
    prechr23 = parseInt(prechr23.split('%')[0]);
    if (nowhr < 10) {
        var nowhrstring = "0"+nowhr.toString();
    } else {
        var nowhrstring = nowhr.toString();
    }
    var myHourTempArray =[hr0, hr1, hr2, hr3, hr4, hr5, hr6, hr7, hr8, hr9, hr10, hr11, hr12, hr13, hr14, hr15, hr16, hr17, hr18, hr19, hr20, hr21, hr22, hr23];
    var myHourPrecArray =[prechr0, prechr1, prechr2, prechr3, prechr4, prechr5, prechr6, prechr7, prechr8, prechr9, prechr10, prechr11, prechr12, prechr13, prechr14, prechr15, prechr16, prechr17, prechr18, prechr19, prechr20, prechr21, prechr22, prechr23];
    var myHourArray = [hrclock0, hrclock1, hrclock2, hrclock3, hrclock4, hrclock5, hrclock6, hrclock7, hrclock8, hrclock9, hrclock10, hrclock11, hrclock12, hrclock13, hrclock14, hrclock15, hrclock16, hrclock17, hrclock18, hrclock19, hrclock20, hrclock21, hrclock22, hrclock23];
    var mytempstring = "";
    var idstring = "";
    var arrayLength = myHourArray.length;
    var tempbarheight = 0;
    var precbarheight = 0;
    var temphrspan = maxhr - minhr;
    if (temphrspan === 0) { 
        temphrspan = 1; 
    }
    var rainchecker = 0;
    var raincheckerstring = "";
    var j = parseInt(myHourArray[0]);
    for (var i = 0; i < arrayLength; i++) {
        if (j < 10) {
            idstring = "0"+j.toString();
        } else {
            idstring = j.toString();
        }
        if ((myHourPrecArray[i] >= 40) && (i > 0)) {
            if (rainchecker === 1) {

            } else {
                raincheckerstring = i.toString();
                rainchecker = 1;    
            }
                
        }
        j = j + 1;
        if (j > 23) { j = 0;}
    }
    var hitoday = document.getElementById("high").innerHTML;
    var lotoday = document.getElementById("low").innerHTML;
    var myBadgetxt = document.getElementById("badgetxt").innerHTML;

    // **********************************************************
    // Here you might change some wordings to your needs/language 
    // **********************************************************

    // timed greetings
    // use hour1greet, hour2greet, ... and username values can be defined in config.js
          
    if(nowhr <hour1greet){
            document.getElementById("custom5").innerHTML = "Sleep well, "+username+".";
            document.getElementById("custom2").innerHTML = "Goodnight";
        }else if(nowhr<hour2greet){
            document.getElementById("custom5").innerHTML = username+", good morning.";
            document.getElementById("custom2").innerHTML = "Hello sunshine";
        }else if(nowhr<hour3greet){
            document.getElementById("custom5").innerHTML = "Grab some food, "+username+".";
            document.getElementById("custom2").innerHTML = "Enjoy your day";
        }else if(nowhr<hour4greet){
            document.getElementById("custom5").innerHTML = "Hej, "+username+".";
            document.getElementById("custom2").innerHTML = "Good afternoon";
        }else if(nowhr<hour5greet){
            document.getElementById("custom5").innerHTML = "Relax, "+username+".";
            document.getElementById("custom2").innerHTML = "Coffee time";
        }else{
            document.getElementById("custom5").innerHTML = "Sleep well, "+username+".";
            document.getElementById("custom2").innerHTML = "Goodnight";
    }
    var updateval = document.getElementById("update").innerHTML;
    document.getElementById("update").innerHTML = "Update " + updateval;

    // do some checks to provide proper precipitation output, e.g. rain, snow
    var currenticonsrc = document.getElementById("weathercode").innerHTML;
    currenticonsrc = currenticonsrc.split('.png')[0];
    if ((currenticonsrc === "6d") || (currenticonsrc === "6n")|| (currenticonsrc === "5d")|| (currenticonsrc === "5n")|| (currenticonsrc === "8d")|| (currenticonsrc === "8n") ||  (currenticonsrc === "9d") || (currenticonsrc === "9n")|| (currenticonsrc === "10d")|| (currenticonsrc === "10n")|| (currenticonsrc === "11d")|| (currenticonsrc === "11n")) {
        if ((currenticonsrc === "6d") || (currenticonsrc === "6n")|| (currenticonsrc === "5d")|| (currenticonsrc === "5n")|| (currenticonsrc === "8d")|| (currenticonsrc === "8n")) {
            //var raininfo = '<font style="color: rgba(58, 173, 254, 1);">It is raining right now.</font>'; 
            var raininfo = '<font style="color: #fff;">It is raining right now.</font>'; 
        }
        if ((currenticonsrc === "9d") || (currenticonsrc === "9n")|| (currenticonsrc === "10d")|| (currenticonsrc === "10n")|| (currenticonsrc === "11d")|| (currenticonsrc === "11n")) {
            //var raininfo = '<font style="color: rgba(58, 173, 254, 1);">It is snowing right now.</font>'; 
            var raininfo = '<font style="color: #fff;">It is snowning right now.</font>'; 
        }
    } else {
        if (rainchecker ===1) {
            //var raininfo = '<font style="color: rgba(58, 173, 254, 1);">Precipitation may start in ' + raincheckerstring + ' hrs.</font>';
            var raininfo = '<font style="color: #fff;">It will start to rain in  ' + raincheckerstring + ' hours.</font>';
        } else {
            //var raininfo = "No rain in the next 24 hrs expected.";
            var raininfo = "No precipitation expected for the next 24 hours.";
        }
    }
    /*document.getElementById("custom6").innerHTML = descstring + "  " + tempstring;*/

    document.getElementById("custom6descbox").innerHTML = username + ", right now " + descstring + " in " + citystring + " with <font style='font-size: 3vw; color: #fff;'>" +tempstring+ "</font>.<br>Today's high at  <font style='color: #fff;'>" +hitoday+ "</font> and the low at <font style='color: #fff;'>" + lotoday+ "</font>.<br>" + raininfo;

    document.getElementById("custom8raininfo").innerHTML = raininfo;

    document.getElementById("custom7temp").innerHTML = tempstring + "C";

    document.getElementById("myBattery").innerHTML = updateval + " • " + batterylevel + "%";

    document.getElementById("myBadgetxt").innerHTML = "EVENTS | " + "<font style='color: #de4759;'>" + myBadgetxt + "</font>";

});
