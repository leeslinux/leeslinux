// **********************************
// *  config.js for WeatherHTML 2.0 *
// *        by thewaytozion         *
// **********************************


// *******************************************************************
// * GENERAL                                                           *
// *                                                                 *
// * IN GERNERAL  avoid spaces before and after the equal sign "="   *
// *******************************************************************

var username="Mone";
var showProfilePic=0;
var date1="[- ]DD/MM/YYYY";
var date2="dddd";
var date3="YYYY";

// *******************************************************************
// * FONTS                                                           *
// *                                                                 *
// * In case you use custom fonts, make sure you added the           *
// * font file names in the customfont.css file.                     *
// * avoid empty lines in customfont.css                             *
// *******************************************************************

var useCustomFont=1;

// *******************************************************************
// * WEATHER                                                         *
// *******************************************************************

var showdailyforecast=0;
var showhourlyforecast=0;
var showweatherwalls=0;
var showsunmoon=0;
var usecoloredtemperature=0;
// in case you are running your sytem in °F, use 1 else use 0 for Celsius
var useFahrenheit=0;
// Define string below for hourly forecast, e.g o'clock
var clockstring = " h";

// *******************************************************************
// * WALLPAPER OPTIONS                                               *
// *******************************************************************

var showbackgroundimage=1;
var usedaynightbackgroundimage=0;
var showtimedwalls=0;
var showoverlay1=1;
var showoverlay2=1;
var showoverlay3=0;
var useMaps=0;
// timed wallpaper related options, define hours to switch wallpaper
var hour1greet=5;
var hour2greet=11;
var hour3greet=14;
var hour4greet=17;
var hour5greet=22;

// *******************************************************************
// * BATTERY                                                         *
// *******************************************************************

var useBatteryBar=1;
var useBatteryCircle=0;

// *******************************************************************
// * CALENDAR                                                        *
// *******************************************************************

var useCalendar=1;
var showmonthlyCalendar=0;
var showweeklyCalendar=0;
var maxTodaycalentries=0;
var maxTomorrowcalentries=0;
var hideTomorrowCalEntriesIfTodayEntryFound=0;
var Calendar1Name="Test1";
var Calendar2Name="Test2";

// *******************************************************************
// * RSS FEED                                                        *
// *******************************************************************

var useRSS=0;
var charcountRSS=180;
var RSSFeed="https://www.tagesschau.de/xml/rss2/";